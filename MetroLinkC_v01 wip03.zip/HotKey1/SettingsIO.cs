﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Collections;

namespace NSSettingsIO
{
    public class SettingsIO
    {
        public string XmlIniFile = "settingsAlt.xml";

            //SettingsFile = "settings.xml"; //const

        public void XMLReadElements()
        {
            XmlDocument xmlini = new XmlDocument();
            xmlini.Load(XmlIniFile);

            XmlElement root = xmlini.DocumentElement; //Evaluate root nodes
            Console.WriteLine("Root nodes: " + root.ChildNodes.Count.ToString());  //TEMP
            for (int i = 0; i < root.ChildNodes.Count; i++) 
            {
                XmlNode node = root.ChildNodes[i];
                if (node.NodeType==XmlNodeType.Element)
                {
                    //Console.WriteLine(node.Name);  //TEMP
                    //Console.WriteLine(node.NodeType); //TEMP

                    switch (node.Name)
                    {
                        case "Tiles":   //Evaluate child nodes
                            Console.WriteLine("Tiles ChildNodes to process: " + node.ChildNodes.Count.ToString());  //TEMP
                            XmlNodeList elemList = node.ChildNodes;
                            IEnumerator elemEnum = elemList .GetEnumerator();
                            
                            while (elemEnum.MoveNext())
                            {
                                XmlNode elemNode = (XmlNode)elemEnum.Current;
                                //Console.WriteLine(title.InnerText);
                                if (elemNode.NodeType == XmlNodeType.Element)
                                {
                                    Console.WriteLine("Process " + elemNode.Name);
                                    Console.WriteLine("Process " + elemNode.InnerXml);
                                
                                }
                            }

                            break;
                        case "HotkeySettings": //Evaluate child nodes
                                    XmlNode nodeHotkeys = node;
                                    Console.WriteLine("Process Hotkeys: " + nodeHotkeys.ChildNodes.Count.ToString());    //TEMP
                        //Console.WriteLine("HotkeySettings: " + node.ChildNodes.Count.ToString());
                            break;
                        case "MetroColors":  //Evaluate child nodes
                                    XmlNode nodeColors = node;
                                    Console.WriteLine("Process MetroColors: " + nodeColors.ChildNodes.Count.ToString()); //TEMP   
                            //Console.WriteLine("MetroColors: " + node.ChildNodes.Count.ToString());
                            break;
                        case "TileSettings":  //Evaluate child nodes
                            XmlNode nodeSettings = node;
                            Console.WriteLine("Process TileSettings: " + nodeSettings.ChildNodes.Count.ToString()); //TEMP
                            //Console.WriteLine("TileSettings: " + node.ChildNodes.Count.ToString());
                            break;
                        default:
                            break;
                    }

                }
            }


            //Console.WriteLine(root.ChildNodes[i].InnerText
            //XmlNode node = nodes[0];
            //XmlNode childNode = node.ChildNodes[0];

        }



    }
}
