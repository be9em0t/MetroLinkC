﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace HotKey1
{
    public class SettingsIO
    {
        public string XmlIniFile = "settingsAlt.xml";

            //SettingsFile = "settings.xml"; //const

        public void XMLReadElements()
        {
            XmlDocument xmlini = new XmlDocument();
            xmlini.Load(XmlIniFile);

            XmlElement root = xmlini.DocumentElement; //Evaluate root nodes
            Console.WriteLine(root.ChildNodes.Count.ToString());
            for (int i = 0; i < root.ChildNodes.Count; i++) 
            {
                XmlNode node = root.ChildNodes[i];
                if (node.NodeType==XmlNodeType.Element)
                {
                    Console.WriteLine(node.Name);
                    Console.WriteLine(node.NodeType);

                    switch (node.Name)
                    {
                        case "Tiles":   //Evaluate child nodes
                            XmlNode nodeTiles = node;
                            Console.WriteLine("ChildNodes Tiles: " + nodeTiles.ChildNodes.Count.ToString());
                            //for (int j = 0; j < node.ChildNodes.Count; i++)
                            //{
                            //    //XmlNode node = root.ChildNodes[i];
                            //    //Console.WriteLine(node.ChildNodes[i].InnerText);
                            //}
                

                            break;
                        case "HotkeySettings": //Evaluate child nodes
                                    XmlNode nodeHotkeys = node;
                                    Console.WriteLine("ChildNodes Hotkeys: " + nodeHotkeys.ChildNodes.Count.ToString());    
                        //Console.WriteLine("HotkeySettings: " + node.ChildNodes.Count.ToString());
                            break;
                        case "MetroColors":  //Evaluate child nodes
                                    XmlNode nodeColors = node;
                                    Console.WriteLine("ChildNodes MetrColors: " + nodeColors.ChildNodes.Count.ToString());    
                            //Console.WriteLine("MetroColors: " + node.ChildNodes.Count.ToString());
                            break;
                        case "TileSettings":  //Evaluate child nodes
                            XmlNode nodeSettings = node;
                            Console.WriteLine("ChildNodes TileSettings: " + nodeSettings.ChildNodes.Count.ToString());
                            //Console.WriteLine("TileSettings: " + node.ChildNodes.Count.ToString());
                            break;
                        default:
                            break;
                    }

                }
            }


            //Console.WriteLine(root.ChildNodes[i].InnerText
            //XmlNode node = nodes[0];
            //XmlNode childNode = node.ChildNodes[0];

        }

        public void ChinditVersion(string[] args)
            {
                // Create an isntance of XmlTextReader and call Read method to read the file
                XmlTextReader textReader = new XmlTextReader("settings.xml");
                textReader.Read();
                // If the node has value
                while (textReader.Read())
                {
                    // Move to fist element
                    textReader.MoveToElement();
                    Console.WriteLine("XmlTextReader Properties Test");
                    Console.WriteLine("===================");
                    // Read this element's properties and display them on console
                    Console.WriteLine("Name:" + textReader.Name);
                    Console.WriteLine("Base URI:" + textReader.BaseURI);
                    Console.WriteLine("Local Name:" + textReader.LocalName);
                    Console.WriteLine("Attribute Count:" + textReader.AttributeCount.ToString());
                    Console.WriteLine("Depth:" + textReader.Depth.ToString());
                    Console.WriteLine("Line Number:" + textReader.LineNumber.ToString());
                    Console.WriteLine("Node Type:" + textReader.NodeType.ToString());
                    Console.WriteLine("Attribute Count:" + textReader.Value.ToString());
                }
            }

        public void XMLElementTest(string[] args)
        {
            // Create an isntance of XmlTextReader and call Read method to read the file
            XmlTextReader textReader = new XmlTextReader("settingsAlt.xml");
            textReader.Read();
            // If the node has value
                       while (textReader.Read())
                        {
            //textReader.ReadStartElement();
                            // Move to fist element
                            textReader.MoveToElement();
                            ////Console.WriteLine("XmlTextReader Properties Test");
                            ////Console.WriteLine("===================");
                            // Read this element's properties and display them on console
                            Console.WriteLine("Name:" + textReader.Name);
                            Console.WriteLine("Line Number:" + textReader.LineNumber.ToString());
                           Console.WriteLine("Base URI:" + textReader.BaseURI);
                            Console.WriteLine("Local Name:" + textReader.LocalName);
                            Console.WriteLine("Attribute Count:" + textReader.AttributeCount.ToString());
                            Console.WriteLine("Depth:" + textReader.Depth.ToString());
                            Console.WriteLine("Node Type:" + textReader.NodeType.ToString());
                            Console.WriteLine("Attribute Count:" + textReader.Value.ToString());
                        }
            
        }


        public void XMLReadElementsVer4()
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            using (XmlReader reader = XmlReader.Create("settingsAlt.xml", settings))
            {

                // Only detect start elements.

                    reader.ReadToFollowing("Tile");
                    //reader.Skip();

                    // Create another reader that contains just the second book node.
                    XmlReader subReader = reader.ReadSubtree();
                    //                subReader.ReadToDescendant("Title");
                
                if (subReader.IsStartElement())
                    {

                            subReader.Read();
                            string elemName = subReader.Name;
                            string elemContent = subReader.ReadElementContentAsString();
                            Console.WriteLine("Name: " + elemName + " Content: " + elemContent);
                        
                      }
                    subReader.Close();

                
            }
        }

        public void XMLReadElementsVer3()
        {
            // Create an XML reader for this file.
            //using (XmlReader reader = XmlReader.Create("settingsAlt.xml"))
            XmlTextReader reader = new XmlTextReader("settingsAlt.xml");
            {
                reader.WhitespaceHandling = WhitespaceHandling.None;
                while (reader.Read())
                {
                    // Only detect start elements.
                    if (reader.IsStartElement())
                    {

                        if (reader.Name == "Tile")
                        {
                            reader.Read(); //read next element
                            string elemName = reader.Name;
                            string elemContent = reader.ReadElementContentAsString();
                            Console.WriteLine("Name:" + elemName + " Content: " + elemContent);
                            XmlReader subReader = reader.ReadSubtree();
                            while (subReader.Read())
                            {
                                subReader.MoveToElement();
                                string subElemName = subReader.Name;
                                string subElemContent = subReader.ReadElementContentAsString();
                                Console.WriteLine("SubName:" + subElemName + " Content: " + subElemContent);

                            }

                            //Console.WriteLine("Node Type:" + reader.NodeType.ToString());
                            //Console.WriteLine("LocalName:" + reader.LocalName);
                        }
                    }
                }
            }
        }

        public void XMLReadElementsAll()
        {
            // Create an XML reader for this file.
            //using (XmlReader reader = XmlReader.Create("settingsAlt.xml"))
            XmlTextReader reader = new XmlTextReader("settingsAlt.xml");
            {
                reader.WhitespaceHandling = WhitespaceHandling.None;   
                while (reader.Read())
                {
                    // Only detect start elements.
                    if (reader.IsStartElement())
                    {

                        if (reader.Name == "Tile")
                        {
                            reader.Read(); //read next element
                            string elemContent = reader.ReadElementContentAsString();
                            Console.WriteLine("Name:" + reader.Name + " Content: " + elemContent);
                            XmlReader subReader = reader.ReadSubtree();
                            while (subReader.Read())
                            {
                                subReader.MoveToElement();
                                string subElemContent = subReader.ReadElementContentAsString();
                                Console.WriteLine("SubName:" + subReader.Name + " Content: " + subElemContent);

                            }

                            //Console.WriteLine("Node Type:" + reader.NodeType.ToString());
                            //Console.WriteLine("LocalName:" + reader.LocalName);
                        }
                    }
                    {
                        // Get element name and switch on it.
                        /* switch (reader.Name)
                        {
                            case "Data":
                                // Detect this element.
                                Console.WriteLine("Start <Data> element.");
                                reader.ReadStartElement();
                            Console.WriteLine("Name:" + reader.Name);
                            Console.WriteLine("LocalName:" + reader.LocalName);

                            Console.WriteLine("Node Type:" + reader.NodeType.ToString());
                            Console.WriteLine("Depth:" + reader.Depth.ToString());
                            break;
                            case "MetroColors":
                                // Detect this article element.
                                Console.WriteLine("Start <MetroColors> element.");
                                // Search for the attribute name on this current node.
                                string attribute = reader["name"];
                                if (attribute != null)
                                {
                                    Console.WriteLine("  Has attribute name: " + attribute);
                                }
                                // Next read will contain text.
                                if (reader.Read())
                                {
                                    Console.WriteLine("  Text node: " + reader.Value.Trim());
                                }
                                break;
                        } */
                    }
                }
            }
        }

    }
}
