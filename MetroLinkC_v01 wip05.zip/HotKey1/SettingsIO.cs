﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Collections;


//using System.Text.RegularExpressions;

namespace XMLSettingsIO
{
    public class SettingsIO
    {
        //SettingsFile = "settings.xml"; //const - check what type of variable is this
        public string XmlIniFile = "settingsAlt.xml";
        Dictionary<String, MetroForm.Tile> dictTiles = new Dictionary<string, MetroForm.Tile>();


        public void XMLReadElements()
        {
            XmlDocument xmlini = new XmlDocument();
            try
            {
                xmlini.Load(XmlIniFile);
            }
            catch (XmlException e)
            {             
                System.Windows.Forms.MessageBox.Show(e.Message, "MetroLink - Error in Settings file"); 
                MetroForm.MetroForm.ActiveForm.Close();
                return;
            }

            XmlElement root = xmlini.DocumentElement; //Evaluate root nodes - Tiles,Settings/Colors...
            for (int i = 0; i < root.ChildNodes.Count; i++) 
            {
                XmlNode nodeRootChild = root.ChildNodes[i];
                if (nodeRootChild.NodeType == XmlNodeType.Element)
                {

                    switch (nodeRootChild.Name)
                    {
                        case "Tiles":   
                            XmlNode nodeTiles = root.ChildNodes[i]; //Evaluate All Tile nodes 
                            Console.WriteLine("Tiles ChildNodes to process: " + nodeTiles.ChildNodes.Count.ToString());  //TEMP

                            //XmlNodeList elemListNode1 = nodeRootChild.ChildNodes;
                            //IEnumerator elemEnumNode1 = elemListNode1.GetEnumerator();

                            IEnumerator enumNodeTiles = nodeTiles.ChildNodes.GetEnumerator(); //enum all Tile nodes

                            int tileNumber = 0;
                            while (enumNodeTiles.MoveNext())
                            {
                                XmlNode nodeTileCurrent = (XmlNode)enumNodeTiles.Current; //Evaluate Current Tile

                                if (nodeTileCurrent.NodeType == XmlNodeType.Element)
                                {
                                    IEnumerator enumNodeTileCurrentProperties= nodeTileCurrent.ChildNodes.GetEnumerator(); //enum current Tile's child nodes                                   
                                    string currentTile = "Tile" + GeneralUtils.IntDecPlaces(tileNumber); //define Tile.key
                                    while (enumNodeTileCurrentProperties.MoveNext())
                                        {
                                            XmlNode nodeProperty = (XmlNode)enumNodeTileCurrentProperties.Current;
                                            if (nodeProperty.NodeType == XmlNodeType.Element)
                                                {
                                                switch (nodeProperty.Name.ToLower().Trim()) //use lowwercase, trimmed version of XML element
	                                                    {
                                                            case "title":
                                                     dictTiles.Add(currentTile, new MetroForm.Tile() { Title = nodeProperty.InnerXml.Trim() });
                                                     break;
                                                            case "lmb":
                                                            dictTiles[currentTile].LMB=nodeProperty.InnerXml.Trim();
                                                     break;
                                                            case "lmbopt":
                                                            dictTiles[currentTile].LMBopt = nodeProperty.InnerXml.Trim();
                                                     break;
                                                            case "rmb":
                                                     dictTiles[currentTile].RMB = nodeProperty.InnerXml.Trim();
                                                     break;
                                                            case "rmbopt":
                                                            dictTiles[currentTile].RMBopt = nodeProperty.InnerXml.Trim();
                                                     break;
                                                            case "image":
                                                            dictTiles[currentTile].Image = nodeProperty.InnerXml.Trim();
                                                     break;
                                                            case "visible":
                                                            dictTiles[currentTile].Visible = nodeProperty.InnerXml.Trim();
                                                     break;
                                                            case "bg":
                                                            dictTiles[currentTile].BG = nodeProperty.InnerXml.Trim();
                                                     break;
                                                            case "markrun":
                                                            dictTiles[currentTile].MarkRun = nodeProperty.InnerXml.Trim();
                                                     break;
                                                            case "activate":
                                                            dictTiles[currentTile].Activate = nodeProperty.InnerXml.Trim();
                                                     break;
                                                            default:
                                                     break;
	                                                    }
                                                 }
                                         }
                                    Console.WriteLine(currentTile + " >> " + dictTiles[currentTile].Title + " \n: LMB" + dictTiles[currentTile].LMB + " \n LMBOpt:" + dictTiles[currentTile].LMBopt + "\n :RMB" + dictTiles[currentTile].RMB + " \n :RMBOpt" + dictTiles[currentTile].RMBopt);
                                    tileNumber = ++tileNumber; //increment Tile Number 
                                  }

                            }
                     

                            break;
                        case "HotkeySettings": //Evaluate child nodes
                            XmlNode nodeHotkeys = nodeRootChild;
                                    Console.WriteLine("Process Hotkeys: " + nodeHotkeys.ChildNodes.Count.ToString());    //TEMP
                        //Console.WriteLine("HotkeySettings: " + node.ChildNodes.Count.ToString());
                            break;
                        case "MetroColors":  //Evaluate child nodes
                            XmlNode nodeColors = nodeRootChild;
                                    Console.WriteLine("Process MetroColors: " + nodeColors.ChildNodes.Count.ToString()); //TEMP   
                            //Console.WriteLine("MetroColors: " + node.ChildNodes.Count.ToString());
                            break;

                        case "TileSettings":  //Evaluate child nodes
                            XmlNode nodeSettings = nodeRootChild;
                            Console.WriteLine("Process TileSettings: " + nodeSettings.ChildNodes.Count.ToString()); //TEMP
                            //Console.WriteLine("TileSettings: " + node.ChildNodes.Count.ToString());
                            break;
                        default:
                            break;
                    }

                }
            }


            //Console.WriteLine(root.ChildNodes[i].InnerText
            //XmlNode node = nodes[0];
            //XmlNode childNode = node.ChildNodes[0];

        }



    }

    public static class GeneralUtils
    {
        public static string StringFix(string strIn)
        {
            string result = strIn.ToLower();
            return result;
        }
        public static string StringLowTrim(string strIn)
        {
            string result = strIn.ToLower().Trim();
            return result;
        }


        public static string IntDecPlaces(int arg)
        {
            string decPlaces3 = "000"; //target decimal places
            int sourcePlaces = arg.ToString().Length;
            string result = decPlaces3.Substring(0, (decPlaces3.Length-sourcePlaces)) + arg.ToString();

            //Console.WriteLine("Magnitude " + arg.ToString() + " : " + result);
            return result;
          }
    }

    public class Tile_OFF
    {
    public string Title { get; set; }
    public string LMB { get; set; }
    public string LMBopt { get; set; }
    public string RMB { get; set; }
    public string RMBopt { get; set; }
    public string Image { get; set; }
    public string Visible { get; set; }
    public string BG { get; set; }
    public string MarkRun { get; set; }
    public string Activate { get; set; }
    }
}
